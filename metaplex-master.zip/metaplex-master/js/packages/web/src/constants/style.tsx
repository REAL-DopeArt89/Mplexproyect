export const GUTTER = [16, { xs: 8, sm: 16, md: 16, lg: 16 }] as any;

export const SMALL_STATISTIC: React.CSSProperties = {
  fontSize: 10,
};
